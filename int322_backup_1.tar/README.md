# int322site

CRUD site developed using LAMP stack

CentOs Server

Apache

Mysql

Php

Live link: https://tinyurl.com/int322site
